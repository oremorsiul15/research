$(".progress").hide();
firebase.auth().onAuthStateChanged(u => {
    if (u) {
        db.collection('docs').orderBy('date','desc').get().then((docs)=>{
            docs.docs.forEach((i)=>{
                document.getElementById("docs").innerHTML += `
                <div class="card">
  <div class="card-header">
    Featured
  </div>
  <div class="card-body">
    <h5 class="card-title">Special title treatment</h5>
    <p class="card-text">With supporting text below as a natural lead-in to additional content.</p>
    <a href="${i.data().url}" class="btn btn-primary">open</a>
  </div>
</div>
                `
            });
        }).catch(e=>console.log(e));
    }
});

let fileEl = document.getElementById("customFile");
let progress = document.getElementById("prog");
let file;
let storageRef;
fileEl.addEventListener('change', (e) => {
    //get file
    file = e.target.files[0];
    storageRef = firebase.storage().ref('docs/' + file.name)
    console.log("got file")
});
function upload() {



    let task = storageRef.put(file);
    $(".progress").show();
    task.on("state_changed", (status) => {
        let percentage = (status.bytesTransferred / status.totalBytes) * 100;
        
        $("#prog").show();
        $("#prog").val(percentage);
        $("#prog").text(percentage+"%");
        $("#prog").attr("aria-valuenow",percentage);
        $("#prog").css("width",percentage+"%");
        console.log(percentage)
        
    }, e => {
        console.log(e);
        alert("unable to upload file");
    }, (e) => {
        
        task.snapshot.ref.getDownloadURL().then(function (downloadURL) {
            let url = downloadURL;
            db.collection('docs').add({
                date: new Date(),
                fileName: file.name,
                url: url,
                title: $("#title").val(),
                description: $("#description").val()
            });
        });
        
    });
}