

let dest = [];

db.collection('users').get()
    .then(snapshot => {
        snapshot.docs.forEach((contact) => {
            $('#inputGroupSelect02')
                .append($("<option></option>")
                    .attr("value", contact.id)
                    .text(contact.id));
            console.log(contact);
        });
    })
    .catch(e => {
        console.log(e);
    });

//my tasks
firebase.auth().onAuthStateChanged(firebaseUser => {
    db.collection("users/" + firebaseUser.email  +"/tasks").orderBy("date","desc").get().then((tasks) => {
        tasks.docs.forEach((task) => {
            let t = task.data();
            document.getElementById("myTasks").innerHTML += `
        <div class="card">
            <div class="card-header">
                ${t.title}
            </div>
            <div class="card-body">
            <blockquote class="blockquote mb-0">
            <p>${t.description}</p>
            <footer class="blockquote-footer">${Math.abs(moment().diff(t.deadline.toDate(), 'days'))} days left <cite title="Source Title"> posted on ${t.date.toDate()}</cite></footer>
            </blockquote>
            </div>
        </div>`;
            

        });
    }).catch(e => console.log(e));
});
function addDest() {
    dest.push($('#inputGroupSelect02').val());
    $('#destLs')
        .append($(`<div ></div>`)
            .attr("class", "alert alert-primary")
            .attr("role", "alert")
            .text("for: " + $('#inputGroupSelect02').val()));
    console.log(dest);
}

function postTask() {

    dest.forEach(email => {
        db.collection("users/" + email + "/tasks").add({
            title: $("#titleTB").val(),
            description: $("#descriptionTB").val(),
            deadline:new Date($("#deadlineTB").val()),
            date: new Date()
        }).catch((e) => console.log(e));

        console.log(`adding to us users/${email}/tasks`);
    });
}
